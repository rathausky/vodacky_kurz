$.ajax({
  url: "test.html",
method: "POST",
success: function($result) {
console.log($result),
})

})